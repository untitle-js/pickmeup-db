package com.pickmeup.api.controller;

import com.pickmeup.api.dao.UserDao;
import com.pickmeup.api.model.Users;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.pickmeup.api.Service.UserService;
import java.util.Map;
/**
 * Created by Renz on 11/2/16.
 */
@RestController
@RequestMapping("/user" )
public class UsersController {

    @RequestMapping(value = "/register", method = RequestMethod.GET)
    public Users register(@RequestParam Map<String, String> params) {
        UserDao dao = new UserDao();
        int userId = (int) (Math.random() * 1000);
        params.put("userId", String.valueOf(userId));
        return dao.registerUser(params);
    }

 @RequestMapping(value="/login" , method = RequestMethod.GET)
    public Users  login(@RequestParam Map<String,String> allRequest)
    {
        UserService service = new UserService();
        Users flagUser= service.validateUser(allRequest);
        return flagUser;
    }
}
