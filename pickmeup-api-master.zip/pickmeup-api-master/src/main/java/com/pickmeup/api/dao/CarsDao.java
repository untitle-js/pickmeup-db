package com.pickmeup.api.dao;

import com.pickmeup.api.model.Carpool;
import com.pickmeup.api.model.Cars;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.text.SimpleDateFormat;
/**
 * Created by Govind on 12/22/2016.
 */


public class CarsDao {

    public Cars registerCar(Map <String,String> param)
    {
        SessionFactory sessionFactory = new Configuration().configure()
                .buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        Cars car = new Cars();
        car.setCarMake(param.get("carMake"));
        car.setOccupancy(Integer.parseInt(param.get("occupancy")));
        car.setCarID(Integer.parseInt(param.get("carId")));
        car.setUserId(Integer.parseInt(param.get("userId")));
        car.setColor(param.get("color"));
        car.setModel(param.get("model"));
        try
        {
            session.saveOrUpdate(car);
            session.getTransaction().commit();

        }
        catch(Exception ex)
        {
            session.getTransaction().rollback();
            throw ex;
        }
        finally
        {
            session.close();
        }

        return car;
    }

    public List<Carpool> listCarpool(Map <String,String> params)
    {
        SessionFactory sessionFactory = new Configuration().configure()
                .buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
       // String listTime =params.get("time");
        Date date = new Date();
        Timestamp current_timestamp =new Timestamp(date.getTime());
        System.out.println("-----------------------------------");
        System.out.println(current_timestamp);
        System.out.println("-----------------------------------");
        String hql=String.format("FROM Carpool c WHERE c.startingTime >=:current_timestamp");
        Query q =session.createQuery(hql);


        q.setParameter("current_timestamp", current_timestamp);
        List<Carpool> carsList = q.list();
        return carsList;
    }

    public Carpool addCarpool(Map <String,String> params)
    {
        SessionFactory sessionFactory = new Configuration().configure()
                .buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        Carpool carpool = new Carpool();
        carpool.setUserid(Integer.parseInt(params.get("userId")));
        carpool.setStartingLocation(params.get("startingLocation"));

        //String timeString = params.get("startingTime");
        final String str = params.get("startingTime");//"14:21:16";
        final Timestamp timestamp =
                Timestamp.valueOf(
                        new SimpleDateFormat("yyyy-MM-dd ")
                                .format(new Date()) // get the current date as String
                                .concat(str)        // and append the time
                );

        carpool.setStartingTime(timestamp);
        carpool.setStartingLocation(params.get("startingLocation"));
        carpool.setDestination(params.get("destination"));
        try
        {
            session.saveOrUpdate(carpool);
            session.getTransaction().commit();

        }
        catch(Exception ex)
        {
            session.getTransaction().rollback();
            throw ex;
        }
        finally
        {
            session.close();
        }

        return carpool;

    }
}
